# Demo Video Script (target 4-5 minutes)

Record with Zoom/Teams "record", OBS, or Windows Game Bar (Win+G). Keep the dashboard open in the browser and the repo open in VS Code.

| Time | Show | Say |
|---|---|---|
| 0:00-0:30 | Title / README | Introduce yourself, the internship, and the project goal: help administrators see operational performance and get data-driven recommendations. |
| 0:30-1:15 | Repo structure in VS Code | Walk through `data/`, `src/`, `dashboard/`, `agile/`, `docs/`. Mention dataset: 10,000 admissions, 15 fields. |
| 1:15-2:00 | Terminal: run `python src/healthcare_ops_analytics.py ...` | Explain the pipeline: cleaning, LOS derivation, scorecard, forecast, decision engine; show console output and generated files. |
| 2:00-3:00 | Dashboard → Overview | Explain the five KPI cards, monthly volume, admission mix, test results, age and gender charts. |
| 3:00-3:40 | Conditions tab | Explain scorecard status logic; point out Asthma and Diabetes = Watch; show billing by condition and by insurer. |
| 3:40-4:10 | Forecast tab | Explain regression, flat trend, R² ≈ 0.001, and why (synthetic data, no seasonality). |
| 4:10-4:40 | Decisions tab | Read the 3 recommendations and what action each implies. |
| 4:40-5:00 | Wrap-up | Limitations (synthetic data, no occupancy/readmission fields), future work (real EHR feed, seasonal model, patient-level risk model), thank mentors. |
