# Test Plan & Results

| ID | Test | Expected | Result |
|---|---|---|---|
| T1 | Pipeline runs on supplied CSV | Exit 0, 4 output files created | Pass |
| T2 | Row count after load | 10,000 | Pass |
| T3 | Derived LOS within 1-30 days, none negative | min 1, max 30 | Pass |
| T4 | Total admissions across conditions = 10,000 | 1650+1708+1703+1623+1688+1628 = 10,000 | Pass |
| T5 | Forecast excludes partial Oct-2018 month | First month in series = 2018-11 | Pass |
| T6 | Exported analytical CSV has no Name/Doctor columns | Columns absent | Pass |
| T7 | Dashboard script executes without errors (stubbed DOM) | 11 charts created, tables populated | Pass |
| T8 | Dashboard renders in browser with internet access | All 5 tabs render | **Verify manually before demo** |
| T9 | Dashboard layout at <900px width | Single-column, nav scrolls horizontally | **Verify manually before demo** |

Run T1-T6 with `python src/healthcare_ops_analytics.py data/healthcare_dataset.csv outputs`.
