# Deployment Guide (GitHub Pages)

The dashboard is a single static file, so deployment is free and takes ~2 minutes.

1. Push the repository to GitHub (see commands below).
2. Repo → **Settings → Pages**.
3. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)` → Save.
4. Because the built file is at `dashboard/index.html`, your live URL will be
   `https://<username>.github.io/<repo-name>/dashboard/`
   (To get a shorter URL, copy `dashboard/index.html` to the repo root as `index.html`.)
5. Wait ~1 minute, open the URL, and paste it into the README and your submission.

## First push
```bash
git init
git add .
git commit -m "Healthcare Operations Intelligence Dashboard - final submission"
git branch -M main
git remote add origin https://github.com/<username>/<repo-name>.git
git push -u origin main
```

## Alternatives
Netlify Drop (drag the `dashboard` folder), Vercel, or Cloudflare Pages all work the same way.
