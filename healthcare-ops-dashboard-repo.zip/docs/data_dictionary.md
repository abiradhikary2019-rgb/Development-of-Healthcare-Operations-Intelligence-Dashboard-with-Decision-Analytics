# Data Dictionary

Source: `data/healthcare_dataset.csv` - 10,000 rows, 15 columns, no missing values. Date format `DD-MM-YYYY`.

| Column | Type | Description |
|---|---|---|
| Name | text | Patient name (synthetic; dropped from exported analytical CSV) |
| Age | int | 18-85 |
| Gender | category | Female / Male |
| Blood Type | category | 8 ABO/Rh types |
| Medical Condition | category | Arthritis, Asthma, Cancer, Diabetes, Hypertension, Obesity |
| Date of Admission | date | 2018-10-30 to 2023-10-30 |
| Doctor | text | Attending doctor (dropped from exported CSV) |
| Hospital | text | 8,639 distinct values (near-unique per row), so not used for grouping |
| Insurance Provider | category | Aetna, Blue Cross, Cigna, Medicare, UnitedHealthcare |
| Billing Amount | float | ~$1,000 - $50,000 |
| Room Number | int | 101-500 (not used: no occupancy semantics) |
| Admission Type | category | Elective, Emergency, Urgent |
| Discharge Date | date | Always after admission |
| Medication | category | Aspirin, Ibuprofen, Lipitor, Paracetamol, Penicillin |
| Test Results | category | Normal, Abnormal, Inconclusive |

## Derived fields
| Field | Definition |
|---|---|
| Length of Stay | Discharge Date − Date of Admission, in days (range 1-30) |
| Admission Month | `YYYY-MM` of admission |
| Is Abnormal | 1 if Test Results = Abnormal |
| Is Emergency | 1 if Admission Type = Emergency |

## Data-quality notes
- First month (Oct 2018) holds only 8 admissions because data starts on the 30th; the partial month is excluded from the forecast.
- Distributions are near-uniform, consistent with a synthetic dataset.
