# Architecture & Technical Design

```
healthcare_dataset.csv
        │
        ▼
 src/healthcare_ops_analytics.py
   1 load/clean → derive LOS, flags
   2 network KPIs
   3 condition scorecard (z-score status)
   4 monthly forecast (LinearRegression)
   5 decision engine (rules)
        │
        ▼
 outputs/  dashboard_data.json · condition_scorecard.csv · recommendations.csv · healthcare_dataset_clean.csv
        │
        ▼ src/build_dashboard.py (embeds JSON)
 dashboard/index.html  (Chart.js, static, self-contained) ──► GitHub Pages
```

## Design decisions
- **Static dashboard + precomputed JSON.** No server needed; deploys free on GitHub Pages; the pipeline is the single source of truth for every number.
- **Relative (z-score) thresholds** instead of fixed cut-offs, because there are no clinical targets for this dataset's metrics.
- **Linear regression** for transparency and because history shows no seasonality; R² is reported so users can judge reliability.
- **Partial months dropped** before fitting: including the 8-admission first month produced a false upward trend.
- **Privacy.** Patient `Name` and `Doctor` are removed from exported analytical files; the dashboard embeds only aggregates.

## Decision-engine rules
| Rule | Priority |
|---|---|
| Condition z-score sum > 1.5 (stay, billing, abnormal rate) | High |
| Condition z-score sum > 0.5 | Medium |
| Network trend slope > 2% of mean monthly volume | Medium |
| Condition Emergency share > network + 3 pts | Low |
| Payer average billing > network average + 1% | Low |
