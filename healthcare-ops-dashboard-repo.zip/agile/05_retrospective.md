# Sprint Retrospective (Project Close)

**What went well**
- Clear separation: pipeline → JSON → static dashboard made the numbers reproducible and deployment trivial.
- Early data profiling revealed the dataset's limits, so KPIs were scoped realistically.

**What didn't go well**
- The dataset is synthetic, so findings are modest and trends flat.
- The partial-month bias was caught late (Sprint 3 QA) rather than during data profiling.

**What we learned**
- Always check boundary periods before fitting time-series models.
- Report model fit (R²) alongside forecasts so users can judge reliability.

**Actions for next time**
- Add automated tests in CI (GitHub Actions) · profile time coverage in Sprint 1 · plan the demo video in Sprint 3, not Sprint 4.
