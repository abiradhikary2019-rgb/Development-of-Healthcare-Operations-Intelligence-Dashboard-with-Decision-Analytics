# Sprint Plan

Four one-week sprints. *(Adjust the week/date labels to match your actual internship calendar.)*

| Sprint | Goal | Stories | Points | Key deliverable |
|---|---|---|---|---|
| **1** (Week 1) | Data foundation and headline KPIs | US-01, US-02 | 6 | Cleaned dataset, KPI computation |
| **2** (Week 2) | Descriptive analytics dashboard | US-03, US-04, US-05, US-06 | 13 | Overview + Conditions tabs |
| **3** (Week 3) | Decision analytics | US-07, US-08, US-09 | 15 | Forecast tab, decision engine, exports |
| **4** (Week 4) | Delivery and documentation | US-10, US-11 | 8 | Deployment, README, report, demo video |

Total: 42 story points · velocity target ≈ 10.5 / sprint

## Sprint ceremonies
- Planning: first session of each week · Daily check-in: async (chat/email) · Review/demo: last session of the week · Retrospective: after review (see `05_retrospective.md`)

## Risks & mitigations
| Risk | Mitigation |
|---|---|
| Dataset has no occupancy/staffing/readmission fields | Re-scoped KPIs to fields actually available (LOS, billing, abnormal rate, emergency share) |
| Synthetic data gives flat trends | Report R², state limitation openly, keep engine data-driven so real data works unchanged |
| Partial first month biases the forecast | Detected in QA; boundary months excluded |
