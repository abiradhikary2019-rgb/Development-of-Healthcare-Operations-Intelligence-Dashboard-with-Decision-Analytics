# Product Backlog & User Stories

**Product vision:** give hospital administrators one place to see operational performance, anticipate demand, and act on prioritized, data-driven recommendations.

**Personas:** Hospital Operations Manager (primary) · Quality Officer · Finance / Revenue-Cycle Analyst

| ID | User story | Acceptance criteria | Priority | Points | Sprint | Status |
|---|---|---|---|---|---|---|
| US-01 | As an analyst, I want the raw admissions data loaded and cleaned so that all metrics are trustworthy. | Dates parsed; LOS derived; no nulls/negatives; row count verified | High | 3 | 1 | Done |
| US-02 | As a manager, I want headline KPIs so that I can gauge network health at a glance. | 5 KPIs shown: admissions, avg LOS, avg billing, abnormal rate, emergency share | High | 3 | 1 | Done |
| US-03 | As a manager, I want to see admission volume over time so that I can spot demand patterns. | Monthly line chart over full history | High | 2 | 2 | Done |
| US-04 | As a quality officer, I want a per-condition scorecard so that I can see which conditions deviate from the norm. | Table with admissions, LOS, billing, abnormal rate, emergency share, status | High | 5 | 2 | Done |
| US-05 | As a manager, I want to see admission type, test result, age and gender mixes so that I understand the patient population. | 4 charts on Overview | Medium | 3 | 2 | Done |
| US-06 | As a finance analyst, I want billing broken down by insurer and condition so that I can find cost outliers. | Two bar charts; averages correct | Medium | 3 | 2 | Done |
| US-07 | As a manager, I want a 6-month admission forecast so that I can plan staffing. | Regression forecast chart; slope and R² displayed; partial months excluded | High | 5 | 3 | Done |
| US-08 | As a manager, I want prioritized recommendations so that I know what to act on first. | Rule engine; High/Medium/Low ordering; plain-language detail | High | 8 | 3 | Done |
| US-09 | As a BI user, I want CSV exports so that I can reuse results in Power BI/Tableau. | 3 CSVs + JSON generated | Low | 2 | 3 | Done |
| US-10 | As a stakeholder, I want the dashboard online so that I can view it without installing anything. | Public URL; works on desktop and mobile widths | High | 3 | 4 | Done (deploy by intern) |
| US-11 | As a reviewer, I want README, docs and a demo video so that I can evaluate the project. | README, report, architecture, test plan, video | High | 5 | 4 | Done (video recorded by intern) |

**Definition of Done:** code committed; output reproducible from the README; reviewed against acceptance criteria; documented.

## Icebox (future)
- Seasonal forecasting (SARIMA/Prophet) · patient-level readmission-risk model · live EHR/ADT feed · role-based views
