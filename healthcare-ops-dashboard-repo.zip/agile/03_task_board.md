# Task Board (Kanban snapshot at project close)

| Backlog | In Progress | In Review | Done |
|---|---|---|---|
| Seasonal forecast model *(future)* | - | - | T01 Load & parse CSV |
| Readmission-risk model *(future)* | | | T02 Derive LOS / flags |
| Live data feed *(future)* | | | T03 Network KPI calculation |
| Role-based views *(future)* | | | T04 Condition scorecard + status logic |
| | | | T05 Dashboard layout & navigation |
| | | | T06 Overview charts (volume, mix, results, age, gender) |
| | | | T07 Billing by condition / insurer charts |
| | | | T08 Monthly forecast (linear regression) |
| | | | T09 Fix partial-month forecast bias |
| | | | T10 Decision engine & recommendations |
| | | | T11 CSV / JSON exports (de-identified) |
| | | | T12 Test plan & verification |
| | | | T13 README, architecture, data dictionary |
| | | | T14 Project report |
| | | | T15 Deploy to GitHub Pages *(intern action)* |
| | | | T16 Record demo video *(intern action)* |

> Tip: mirror this in a GitHub Project board (Projects → New → Board) and screenshot it for your submission.
