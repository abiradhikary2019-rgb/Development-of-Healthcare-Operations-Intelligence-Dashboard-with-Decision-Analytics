"""
Healthcare Operations Intelligence Dashboard - Decision Analytics Engine
=========================================================================
Infosys Springboard Virtual Internship 7.0 - Batch 3

Input : data/healthcare_dataset.csv (patient-level admissions extract)
Output: outputs/ (CSV exports + dashboard_data.json consumed by the dashboard)

Pipeline
  1. Load & clean data, derive Length of Stay (LOS)
  2. Network-wide KPIs
  3. Per-condition scorecard with a relative-deviation (z-score) status flag
  4. Monthly admission forecast (linear regression), network and per condition
  5. Rule-based decision engine -> prioritized recommendations
  6. Export CSV / JSON bundles (Power BI / Tableau ready)

Usage
    pip install -r requirements.txt
    python src/healthcare_ops_analytics.py data/healthcare_dataset.csv outputs
"""

import sys
import json
from pathlib import Path
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


# ---------------------------------------------------------------------------
# 1. LOAD & CLEAN
# ---------------------------------------------------------------------------
def load_dataset(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["Date of Admission"] = pd.to_datetime(df["Date of Admission"], format="%d-%m-%Y")
    df["Discharge Date"] = pd.to_datetime(df["Discharge Date"], format="%d-%m-%Y")
    df["Length of Stay"] = (df["Discharge Date"] - df["Date of Admission"]).dt.days
    df["Admission Month"] = df["Date of Admission"].dt.to_period("M").astype(str)
    df["Is Abnormal"] = (df["Test Results"] == "Abnormal").astype(int)
    df["Is Emergency"] = (df["Admission Type"] == "Emergency").astype(int)
    return df


# ---------------------------------------------------------------------------
# 2. NETWORK-WIDE KPIs
# ---------------------------------------------------------------------------
def network_kpis(df: pd.DataFrame) -> dict:
    return dict(
        total_admissions=int(len(df)),
        avg_length_of_stay=round(df["Length of Stay"].mean(), 2),
        avg_billing=round(df["Billing Amount"].mean(), 2),
        abnormal_test_rate=round(df["Is Abnormal"].mean(), 4),
        emergency_share=round(df["Is Emergency"].mean(), 4),
        date_range=[str(df["Date of Admission"].min().date()),
                    str(df["Date of Admission"].max().date())],
    )


# ---------------------------------------------------------------------------
# 3. CONDITION SCORECARD
# ---------------------------------------------------------------------------
def condition_scorecard(df: pd.DataFrame) -> pd.DataFrame:
    agg = df.groupby("Medical Condition").agg(
        admissions=("Name", "count"),
        avg_los=("Length of Stay", "mean"),
        avg_billing=("Billing Amount", "mean"),
        abnormal_rate=("Is Abnormal", "mean"),
        emergency_share=("Is Emergency", "mean"),
        avg_age=("Age", "mean"),
    ).round(3)

    # z-score each signal against the cross-condition mean, then sum
    for col in ["avg_los", "avg_billing", "abnormal_rate"]:
        mean, std = agg[col].mean(), agg[col].std()
        agg[f"{col}_z"] = (agg[col] - mean) / std if std > 0 else 0

    def status(row):
        z_sum = row["avg_los_z"] + row["avg_billing_z"] + row["abnormal_rate_z"]
        if z_sum > 1.5:
            return "Needs Attention"
        if z_sum > 0.5:
            return "Watch"
        return "On Target"

    agg["status"] = agg.apply(status, axis=1)
    agg = agg.drop(columns=[c for c in agg.columns if c.endswith("_z")])
    return agg.reset_index()


# ---------------------------------------------------------------------------
# 4. FORECASTING
# ---------------------------------------------------------------------------
def monthly_series(df: pd.DataFrame, condition: str = None) -> pd.Series:
    """Monthly admission counts. Partial boundary months (data starting or
    ending mid-month) are dropped so they don't distort the regression."""
    first, last = df["Date of Admission"].min(), df["Date of Admission"].max()
    sub = df if condition is None else df[df["Medical Condition"] == condition]
    counts = sub.groupby("Admission Month").size().sort_index()
    if first.day > 3:
        counts = counts.drop(first.strftime("%Y-%m"), errors="ignore")
    if last.day < 28:
        counts = counts.drop(last.strftime("%Y-%m"), errors="ignore")
    return counts


def forecast_monthly(series: pd.Series, horizon: int = 6) -> dict:
    y = series.values.astype(float)
    X = np.arange(len(y)).reshape(-1, 1)
    model = LinearRegression().fit(X, y)
    future_X = np.arange(len(y), len(y) + horizon).reshape(-1, 1)
    forecast = np.clip(model.predict(future_X), 0, None)
    return dict(
        slope_per_month=round(float(model.coef_[0]), 3),
        r_squared=round(float(model.score(X, y)), 4),
        forecast=[round(float(v), 1) for v in forecast],
    )


# ---------------------------------------------------------------------------
# 5. DECISION ENGINE
# ---------------------------------------------------------------------------
@dataclass
class Recommendation:
    priority: str
    category: str
    title: str
    detail: str


def generate_recommendations(kpis, scorecard, df, network_forecast, net_series) -> list:
    recs = []

    slope = network_forecast["slope_per_month"]
    if slope > 0 and slope / net_series.mean() > 0.02:
        recs.append(Recommendation(
            "medium", "Capacity Planning",
            f"Network admissions trending up ~{slope:.1f}/month",
            "Monthly volume is rising. Revisit staffing and bed-planning assumptions "
            "for the next two quarters using the 6-month forecast."))

    for _, row in scorecard.iterrows():
        cond = row["Medical Condition"]
        if row["status"] == "Needs Attention":
            recs.append(Recommendation(
                "high", "Quality & Cost",
                f"{cond}: elevated cost, stay length, and abnormal-result rate",
                f"{cond}: avg stay {row['avg_los']:.1f} days, avg billing ${row['avg_billing']:,.0f}, "
                f"{row['abnormal_rate']*100:.1f}% abnormal results - all above network average. "
                "Prioritize a care-pathway review."))
        elif row["status"] == "Watch":
            recs.append(Recommendation(
                "medium", "Quality & Cost",
                f"{cond}: metrics trending above network average",
                f"Avg stay {row['avg_los']:.1f} days, billing ${row['avg_billing']:,.0f}, "
                f"abnormal-result rate {row['abnormal_rate']*100:.1f}%. Monitor next quarter before escalating."))

        if row["emergency_share"] > kpis["emergency_share"] + 0.03:
            recs.append(Recommendation(
                "low", "Patient Load",
                f"{cond}: higher-than-average share of Emergency admissions",
                f"{row['emergency_share']*100:.1f}% of {cond} admissions are Emergency vs "
                f"{kpis['emergency_share']*100:.1f}% network-wide. Consider proactive outpatient management."))

    ins = df.groupby("Insurance Provider")["Billing Amount"].mean().round(0)
    overall = df["Billing Amount"].mean()
    for provider, val in ins.items():
        if val > overall * 1.01:
            recs.append(Recommendation(
                "low", "Revenue Cycle",
                f"{provider}: average billing ${val:,.0f} above network average",
                f"${val:,.0f} vs network average ${overall:,.0f}. Confirm coding and claims "
                f"accuracy for {provider} in the next billing audit."))

    order = {"high": 0, "medium": 1, "low": 2}
    return sorted(recs, key=lambda r: order[r.priority])


# ---------------------------------------------------------------------------
# 6. MAIN
# ---------------------------------------------------------------------------
def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "data/healthcare_dataset.csv"
    out = Path(sys.argv[2] if len(sys.argv) > 2 else "outputs")
    out.mkdir(exist_ok=True, parents=True)

    df = load_dataset(path)
    print(f"Loaded {len(df):,} admissions from {path}\n")

    kpis = network_kpis(df)
    print("=== Network KPIs ===")
    for k, v in kpis.items():
        print(f"  {k}: {v}")

    scorecard = condition_scorecard(df)
    scorecard.to_csv(out / "condition_scorecard.csv", index=False)
    print("\n=== Condition Scorecard ===")
    print(scorecard.to_string(index=False))

    net_series = monthly_series(df)
    net_forecast = forecast_monthly(net_series)
    print("\n=== 6-Month Network Forecast ===")
    print(f"slope={net_forecast['slope_per_month']}/month  R2={net_forecast['r_squared']}")
    print(f"forecast={net_forecast['forecast']}")

    condition_forecasts = {c: forecast_monthly(monthly_series(df, c))
                           for c in df["Medical Condition"].unique()}

    recs = generate_recommendations(kpis, scorecard, df, net_forecast, net_series)
    pd.DataFrame([asdict(r) for r in recs]).to_csv(out / "recommendations.csv", index=False)
    print("\n=== Recommended Actions ===")
    for r in recs:
        print(f"[{r.priority.upper():6}] {r.category:16} {r.title}")

    bundle = dict(
        kpis=kpis,
        scorecard=scorecard.to_dict(orient="records"),
        monthly_labels=list(net_series.index),
        monthly_admissions=[int(v) for v in net_series.values],
        network_forecast=net_forecast,
        condition_forecasts=condition_forecasts,
        admission_type_counts=df["Admission Type"].value_counts().to_dict(),
        test_result_counts=df["Test Results"].value_counts().to_dict(),
        insurance_billing=df.groupby("Insurance Provider")["Billing Amount"].mean().round(0).to_dict(),
        insurance_counts=df["Insurance Provider"].value_counts().to_dict(),
        gender_counts=df["Gender"].value_counts().to_dict(),
        age_bins=np.histogram(df["Age"], bins=[18, 30, 40, 50, 60, 70, 86])[0].tolist(),
        medication_counts=df["Medication"].value_counts().to_dict(),
        recommendations=[asdict(r) for r in recs],
    )
    with open(out / "dashboard_data.json", "w") as f:
        json.dump(bundle, f)

    # de-identified analytical extract (drops patient Name and Doctor)
    df.drop(columns=["Name", "Doctor"]).to_csv(out / "healthcare_dataset_clean.csv", index=False)
    print(f"\nExported to {out}/: condition_scorecard.csv, recommendations.csv, "
          "healthcare_dataset_clean.csv, dashboard_data.json")


if __name__ == "__main__":
    main()
