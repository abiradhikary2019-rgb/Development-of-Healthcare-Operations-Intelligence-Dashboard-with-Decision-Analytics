"""Injects outputs/dashboard_data.json into dashboard/template.html -> dashboard/index.html"""
from pathlib import Path
root = Path(__file__).resolve().parent.parent
data = (root / "outputs" / "dashboard_data.json").read_text()
html = (root / "dashboard" / "template.html").read_text().replace("__DATA_JSON__", data)
(root / "dashboard" / "index.html").write_text(html)
print("Built dashboard/index.html")
